<?php
session_start();

$contacttype = $_SESSION['contacttype'];
$name = $_SESSION['name'];
$email = $_SESSION['email'];
$comment = $_SESSION['comment'];

mb_language("Ja");
mb_internal_encoding("utf-8");

$body = '';
$body2 = '';

$entry_time = date("Y/m/d H:i:s");
$subject = "Miraitas Training Instituteにお問い合せがありました";
$subject2 = "【Miraitas Training Institute】お問い合せ受付";
$to = "mti@mirai-tasu.com";
$header = "From:" .mb_encode_mimeheader("お問い合せの受付") ."<$email>";
$header2 = "From:" .mb_encode_mimeheader("株式会社ミライタス") ."<$to>";
$url = "https://mti.mirai-tasu.com/";

$body =<<<MAILBODY
Miraitas Training Instituteにお問い合せがありました。

━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
　■　お問い合せ内容
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━

【お問い合わせ種別】：{$contacttype}
【お名前】：{$name}　様
【Eメール】：{$email}

【お問い合せ内容】

{$comment}


MAILBODY;

$body2 = <<<MAILBODY
この度はMiraitas Training Institute 運営事務局に
お問い合せいただき、誠にありがとうございます。

ご質問内容を確認し、担当者より折り返しご連絡させていただきます。


　　　　　　　　　株式会社ミライタス　MTI運営事務局
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
　■　お問い合せ内容
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━

【お問い合わせ種別】：{$contacttype}
【お名前】：{$name}　様
【Eメール】：{$email}

【お問い合せ内容】

{$comment}


■━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━■

   株式会社ミライタス
   Miraitas Training Institute 運営事務局
　{$url}

■━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━■

＝＝＝＝＝＝＝＝＝＝＝＝＝＝＝＝＝＝＝＝＝＝＝＝＝＝＝＝＝＝＝＝＝＝＝

このメッセージは、株式会社ミライタスが運営する
Miraitas Training Institute 運営事務局へお問い合せの際に
ご入力頂いたメールアドレス宛に自動的にお送りしています。

このメールにお心当りのない場合は、
株式会社ミライタス　MTI運営事務局までご連絡ください。

＝＝＝＝＝＝＝＝＝＝＝＝＝＝＝＝＝＝＝＝＝＝＝＝＝＝＝＝＝＝＝＝＝＝＝
MAILBODY;


//運営事務局宛メール送信処理
//お客様宛メール送信処理
if(isset($email)){
	$mail_result1 = mb_send_mail($to,$subject,$body,$header,"-f$to"); 
	$mail_result2 = mb_send_mail($email,$subject2,$body2,$header2,"-f$to"); 
}

//送信終了メッセージ格納
if($mail_result1 && $mail_result2){
	header("Location:thanks.php");
 }else{
	session_unset();
	echo 'error';
}
?>