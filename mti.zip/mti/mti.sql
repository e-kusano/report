drop database if exists mti;
create database mti default character set utf8 collate utf8_general_ci;
grant all on shop.* to 'staff'@'localhost' identified by 'mirai0622';
use mti;

create table guest (
	id int auto_increment primary key, 
	name varchar(100) not null, 
	user_id varchar(100) not null unique, 
	password varchar(100) not null
);

insert into guest values(null, 'Guest', 'guest01', '20150622');
insert into guest values(null, 'Guest', 'guest02', '20150622');
