<?php

function html($s) {
return htmlspecialchars($s, ENT_QUOTES, "UTF-8");
}
session_start();

$_SESSION['contacttype'] = $_POST['contacttype'];
$_SESSION['name'] = $_POST['name'];
$_SESSION['email'] = $_POST['email'];
$_SESSION['comment'] = $_POST['comment'];

?>

<!DOCTYPE html>
<html lang="ja">
<head>
<meta charset="UTF-8">
<title>お問い合わせ | Miraitas Training Institute</title>
<meta name="description" content="">
<meta name="keywords" content="">
<meta name="viewport" content="width=device-width,initial-scale=1.0,minimum-scale=1.0,maximum-scale=1.0,user-scalable=no">
<meta name="format-detection" content="telephone=no">
<link rel="canonical" href="">
<link rel="icon" href="../favicon.ico">
<link rel="apple-touch-icon" href="../apple-touch-icon.png" />
<link rel="stylesheet" href="../_css/html5reset-1.6.1.css" />
<link href="http://maxcdn.bootstrapcdn.com/font-awesome/4.7.0/css/font-awesome.min.css" rel="stylesheet">
<link rel="stylesheet" href="../_css/style.css" />
<link rel="stylesheet" href="../_css/style-sp.css" media="only screen and (min-width: 0px) and (max-width: 480px)" />
<link rel="stylesheet" href="../_css/style-tb.css" media="only screen and (min-width: 481px) and (max-width: 768px)"/>
<link rel="stylesheet" href="../_css/style-ipad.css" media="only screen and (min-width: 769px) and (max-width: 1024px)"/>
<link rel="stylesheet" href="../_css/style-pc.css" media="only screen and (min-width: 1025px) "/>
<link href="https//fonts.googleapis.com/css?family=Hind|Yellowtail" rel="stylesheet">
<script src="http//ajax.googleapis.com/ajax/libs/jquery/1.8.2/jquery.min.js"></script>
<script src="../_js/functions.js"></script>
<script src="../_js/jquery.validate.min.js"></script>
</head>
<body>
<div id="bodyBack">
<header>
<div id="titleBox">
<h1>お問い合わせ | <a href="../" class="site-title site-title-a">Miraitas Training Institute</a></h1>
</div>
<p class="menu-trigger">
<i class="fa fa-bars" aria-hidden="true"></i>
</p>
<div id="overlay">
<p id="close"><i class="fa fa-times" aria-hidden="true"></i>close</p>
<ul>
<li><a href="../">MTI TOP</a></li>
<li><a href="../event/">講座・勉強会</a></li>
<li class="navActive">お問い合わせ</li>
</ul>
</div>
<nav id="top-only">
<ul>
<li><a href="../">MTI TOP</a></li>
<li><a href="../event/">講座・勉強会</a></li>
<li class="navActive">お問い合わせ</li>
</ul>
</nav>
</header>

<div id="pageMv" class="trainingPage">
<div id="mv-msg">
<p class="sub-title">お問い合わせ</p>
<h2><span>C</span>ontact</h2>
</div>
</div>
<div id="topicPath">
<ol>
<li><a href="../" class="site-title"><i class="fa fa-th" aria-hidden="true"></i>Miraitas Training Institute</a></li>
<li><a href="../">お問い合せ</a></li>
<li>お問い合せ完了画面</li>
</ol>
</div>
<div id="frontContents">
<div id="contact-form">
<div class="event-wrapper">
<form action="send-mail.php" method="post">
<ol id="contact-flow" class="sp-none ip-none">
<li><span>STEP.1<br>必要事項のご入力</span></li><i class="fa fa-caret-right flow-arrow" aria-hidden="true"></i><li id="contact-flow-active"><span>STEP.2<br>入力内容の確認</span></li><i class="fa fa-caret-right flow-arrow" aria-hidden="true"></i><li><span>STEP.3<br>お問い合せ完了</span></li>
</ol>
<div class="event-content">
<dl>
<dt>お問い合わせ種別</dt>
<dd><?php echo html($_SESSION['contacttype']); ?></dd>
<dt>お名前</dt>
<dd><?php echo html($_SESSION['name']); ?></dd>
<dt>メールアドレス</dt>
<dd><?php echo html($_SESSION['email']); ?></dd>
<dt>お問い合せ内容</dt>
<dd><?php echo html($_SESSION['comment']); ?></dd>
</dl>
</div>
<div id="btn-entry">
<button type="submit">送信する</button>
</div>
</form>
</div>
</div>
</div>
</div>

<footer>
<p id="copyright"><small>Copyright (c) 株式会社ミライタス All Rights Reserved.</small></p>
</footer>
<p id="pageTop"><a href=""><i class="fa fa-chevron-up"></i></a></p>
</body>
</html>