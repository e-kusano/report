<?php
session_start();

function dipEmail(){
	echo $_SESSION['email'];
	session_unset();
}
?>

<!DOCTYPE html>
<html lang="ja">
<head>
<meta charset="UTF-8">
<title>お問い合わせ完了画面 | Miraitas Training Institute</title>
<meta name="description" content="">
<meta name="keywords" content="">
<meta name="viewport" content="width=device-width,initial-scale=1.0,minimum-scale=1.0,maximum-scale=1.0,user-scalable=no">
<meta name="format-detection" content="telephone=no">
<link rel="canonical" href="">
<link rel="icon" href="">
<link rel="apple-touch-icon" href="" />
<link rel="stylesheet" href="../_css/html5reset-1.6.1.css" />
<link href="http://maxcdn.bootstrapcdn.com/font-awesome/4.7.0/css/font-awesome.min.css" rel="stylesheet">
<link rel="stylesheet" href="../_css/style.css" />
<link rel="stylesheet" href="../_css/style-sp.css" media="only screen and (min-width: 0px) and (max-width: 480px)" />
<link rel="stylesheet" href="../_css/style-tb.css" media="only screen and (min-width: 481px) and (max-width: 768px)"/>
<link rel="stylesheet" href="../_css/style-ipad.css" media="only screen and (min-width: 769px) and (max-width: 1024px)"/>
<link rel="stylesheet" href="../_css/style-pc.css" media="only screen and (min-width: 1025px) "/>
<link href="https://fonts.googleapis.com/css?family=Hind|Yellowtail" rel="stylesheet">
<script src="http://ajax.googleapis.com/ajax/libs/jquery/1.8.2/jquery.min.js"></script>
<script src="../_js/functions.js"></script>
<script src="../_js/jquery.validate.min.js"></script>
</head>
<body>
<div id="bodyBack">
<header>
<div id="titleBox">
<h1>お問い合わせ完了画面 | <a href="../" class="site-title site-title-a">Miraitas Training Institute</a></h1>
</div>
<p class="menu-trigger">
<i class="fa fa-bars" aria-hidden="true"></i>
</p>
<div id="overlay">
<p id="close"><i class="fa fa-times" aria-hidden="true"></i>close</p>
<ul>
<li><a href="../">MTI TOP</a></li>
<li><a href="../event/">講座・勉強会</a></li>
<li class="navActive">お問い合わせ</li>
</ul>
</div>
<nav id="top-only">
<ul>
<li><a href="../">MTI TOP</a></li>
<li><a href="../event/">講座・勉強会</a></li>
<li class="navActive">お問い合わせ</li>
</ul>
</nav>
</header>
<div id="pageMv" class="trainingPage">
<div id="mv-msg">
<p class="sub-title">お問い合わせ完了画面</p>
<h2><span>T</span>hanks!</h2>
</div>
</div>
<div id="topicPath">
<ol>
<li><a href="../" class="site-title"><i class="fa fa-th" aria-hidden="true"></i>Miraitas Training Institute</a></li>
<li><a href="../contact">お問い合わせ</a></li>
<li>お問い合わせ完了画面</li>
</ol>
</div>
<div id="frontContents">
<div class="readMsgHead">
<p>お問い合わせ頂き誠にありがとうございます。</p>
<p>【<?php dipEmail(); ?>】宛に<br>受付完了メールを自動送信しております。</p>
</div>
<div id="contact-form">
<div class="event-wrapper">
<ol id="contact-flow" class="sp-none ip-none">
<li><span>STEP.1<br>必要事項のご入力</span></li><i class="fa fa-caret-right flow-arrow" aria-hidden="true"></i><li><span>STEP.2<br>入力内容の確認</span></li><i class="fa fa-caret-right flow-arrow" aria-hidden="true"></i><li id="contact-flow-active"><span>STEP.3<br>お問い合わせ完了</span></li>
</ol>
<div class="event-content">
<p id="thanks-msg">この度は株式会社ミライタスへお問い合わせ頂き、誠にありがとうございました。お送り頂いた内容を確認し、担当より折り返しご連絡いたしますので、今しばらくお待ち下さい。また、お問い合わせの内容により、回答までに少々お時間を頂く場合がございますのでご了承下さい。</p>
<div class="attention-msg">
<p>下記のような場合はお手数ですが、再度お問い合わせフォームより送信して頂くか、お電話等で別途ご連絡下さいませ。</p>
<ul class="alert-msg">
<li><i class="fa fa-exclamation-triangle" aria-hidden="true"></i>数時間経ってもお問い合わせ完了メールが届かない場合</li>
<li><i class="fa fa-exclamation-triangle" aria-hidden="true"></i>メールアドレス、その他の情報を誤って入力した場合</li>
</ul>
<div id="contact-tel">
<p class="admin"><span class="site-title brs">Miraitas Training Institute</span>運営事務局</p>
<ul class="cf">
<li class="admin-tel"><a href="tel:0358178619"><i class="fa fa-phone" aria-hidden="true"></i>03-5817-8619</a></li>
<li>平日9:30-18:30</li>
</ul>
</div>
</div>
</div>
</div><!-- event-wrapper -->
</div><!-- contact-form -->
</div><!-- frontContents -->
<footer>
<p id="copyright"><small>Copyright (c) 株式会社ミライタス All Rights Reserved.</small></p>
</footer>
<p id="pageTop"><a href=""><i class="fa fa-chevron-up"></i></a></p>
</body>
</html>