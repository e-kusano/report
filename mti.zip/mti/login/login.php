<?php

session_start();

unset($_SESSION['guest']);
$pdo=new PDO('mysql:host=localhost;dbname=mti;charset=utf8', 'staff', 'mirai0622');

    $sql=$pdo->prepare('select * from guest where user_id=? and password=?');
    $sql->execute([$_REQUEST['user_id'], $_REQUEST['password']]);
    foreach ($sql->fetchAll() as $row) {
	$_SESSION['guest']=[
		'id'=>$row['id'], 'name'=>$row['name'], 
		'user_id'=>$row['user_id'], 
		'password'=>$row['password']];
	}

if (isset($_SESSION['guest'])) {
	//ユーザ名をセッションに格納してメイン画面へ
	$_SESSION['guest'] = $list[0]['name'];
	header("Location: ../main");

} else {
/*} catch (Exception $e) {*/
	//header("Location: loginerror.html");
	print ('DbError: '. $e->getMessage());
}

?>